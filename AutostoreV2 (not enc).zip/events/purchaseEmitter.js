const { EventEmitter } = require('events');
const purchaseEmitter = new EventEmitter();

module.exports = purchaseEmitter;